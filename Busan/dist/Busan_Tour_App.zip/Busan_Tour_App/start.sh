#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "============================================"
echo "  Busan AI 旅行助手 · 手机版一键启动"
echo "============================================"

if ! command -v python3 >/dev/null 2>&1; then
  echo "[错误] 未检测到 python3，请先安装 Python 3.9+。"; exit 1
fi

if [ ! -d ".venv" ]; then
  echo "[1/3] 创建虚拟环境 .venv ..."
  python3 -m venv .venv
fi

source .venv/bin/activate
echo "[2/3] 安装依赖（首次运行需要联网）..."
pip install --upgrade pip
pip install -r requirements.txt

echo "[3/3] 启动手机版服务 ..."
echo "手机与电脑连同一 Wi-Fi，浏览器访问终端里显示的地址。"
python3 mobile_app.py 8000

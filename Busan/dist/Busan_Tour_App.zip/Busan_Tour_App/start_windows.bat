@echo off
chcp 65001 >nul
title Busan AI Tour App
cd /d "%~dp0"

echo ============================================
echo   Busan AI 旅行助手 · 手机版一键启动
echo ============================================

where python >nul 2>nul
if errorlevel 1 (
  echo [错误] 未检测到 Python，请先安装 Python 3.9+ 并勾选 Add to PATH。
  pause
  exit /b 1
)

if not exist ".venv" (
  echo [1/3] 正在创建虚拟环境 .venv ...
  python -m venv .venv
)

call ".venv\Scripts\activate.bat"

echo [2/3] 正在安装依赖（首次运行需要联网）...
python -m pip install --upgrade pip
pip install -r requirements.txt

echo [3/3] 正在启动手机版服务...
echo 手机与电脑连同一 Wi-Fi，浏览器访问命令行里显示的地址即可。
echo 本窗口保持打开；关闭窗口即停止服务。
start "" http://127.0.0.1:8000/
python mobile_app.py 8000
pause
